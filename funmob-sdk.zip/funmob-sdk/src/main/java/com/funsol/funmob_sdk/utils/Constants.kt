package com.funsol.funmob_sdk.utils

object Constants {

    const val ApiAddress = "https://funsol.cloud/"
    var FunMobPrefKey = "FunMobPreferences"

}